public class UtenteRegistrato {



}
