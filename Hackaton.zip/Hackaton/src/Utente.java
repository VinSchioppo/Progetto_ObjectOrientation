import java.util.Date;

public class Utente {

    String CodiceFiscale;
    String FNome;
    String MNome;
    String LNome;
    Date DataNascita;


}
