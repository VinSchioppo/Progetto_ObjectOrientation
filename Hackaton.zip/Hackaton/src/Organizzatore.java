import java.util.Date;

public class Organizzatore {

    String CodiceFiscale;
    String FNome;
    String MNome;
    String LNome;
    Date DataNascita;

    public Organizzatore(String FNome, String MNome) {

        this.FNome = FNome;
        this.MNome = MNome;

    }

    public void SetFNome(String FNome) {

        this.FNome = FNome;

    }

    public String presentazione(){

        return this.FNome + " " + this.MNome;

    }

}