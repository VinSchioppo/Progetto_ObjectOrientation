import java.util.Date;

public class Evento {

    String titolo;
    String sede;
    Date dataInizio;
    Date dataFine;
    int MaxIscritti;
    int MaxTeam;
    String DescrizioneProblema;
    Date DataInizioReg;
    Date DataFineReg;

}