import java.util.Date;

public class Progressi {

    Date DataProgresso;
    String TestoDocumeto;

}
