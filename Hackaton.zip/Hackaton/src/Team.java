public class Team {

    int idTeam;
    int NumPartecipanti;

}
